<?php
/*
Plugin Name: Mikos Shortcodes
Plugin URI: http://gomalthemes.com/
Description: Mikos shortcodes provides a free set of different shortcodes for your WordPress theme!
Version: 1.0.2
Author: Gomal Themes
Author URI: http://gomalthemes.com/
License: GPLv2
*/

// add in constant name path
defined( 'EF_ROOT' )   or define( 'EF_ROOT',   dirname(__FILE__) );

?>
<?php

if( ! class_exists( 'Mikos_Plugins' ) ) {

    class Mikos_Plugins {

        private $assets_js;

        public function __construct() {
            $this->assets_js = plugins_url('/composer/js', __FILE__);

            include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

            if ( is_plugin_active( 'js_composer/js_composer.php' ) ) {

                require_once( WP_PLUGIN_DIR . '/js_composer/js_composer.php');

                add_action( 'admin_init', array($this, 'wpc_plugin_init') );
                add_action( 'wp', array($this, 'wpc_plugin_init') );
            }
        }

        //include custom map
        public function wpc_plugin_init(){

            require_once( EF_ROOT .'/composer/init.php');

            foreach( glob( EF_ROOT . '/'. 'composer/shortcodes/mikos_*.php' ) as $shortcode ) {
                require_once(EF_ROOT .'/'. 'composer/shortcodes/'. basename( $shortcode ) );
            }

            foreach( glob( EF_ROOT . '/'. 'composer/shortcodes/vc_*.php' ) as $shortcode ) {
                require_once(EF_ROOT .'/'. 'composer/shortcodes/'. basename( $shortcode ) );
            }

        }

    } // end of class

    new Mikos_Plugins;

} // end of class_exists

// Content filter used ONLY on custom theme shortcodes to remove
add_filter("the_content", "the_content_filter");
function the_content_filter($content) {
    // array of custom shortcodes requiring the fix
    $block = join("|",array(
        "services",
        "service",
        "testimonials",
        "team",
        "row",
        "image",
        "counters",
        "counter",
        "projects",
        "pricing",
        "price_col",
        "tab",
        "tabs",
        "column",
        "social",
        "button",
        "space",
        "about",
        "citate",

    ));
// opening tag
    $rep = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]",$content);
// closing tag
    $rep = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)?/","[/$2]",$rep);
    return $rep;
}
//Pricing Shortode
function pricing_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="row pricing">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('pricing', 'pricing_shortcode');
function pricing_col_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['head'])){
        $head = $atts['head'];
    } else {
        $head = "Head Title";
    }
    if(!empty($atts['package'])){
        $package = $atts['package'];
    } else {
        $package = "Package Name";
    }
	if(!empty($atts['subtitle'])){
        $package_subtitle = $atts['subtitle'];
    } else {
        $package_subtitle = "";
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = "Button Text";
    }
    if(!empty($atts['btn_url'])){
        $btn_url = $atts['btn_url'];
    } else {
        $btn_url = "#";
    }
    if(!empty($atts['space'])){
        $space = $atts['space'];
    } else {
        $space = "20px";
    }
    $out = '';
    $out .= '<li class="col-md-4 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
    $out .= '<div>';
    $out .= '<div class="head"><h5>'.$head.'</h5> <hr class="price-line"></div>';
    $out .= '<div class="pkg" style="padding-top: '.$space.';"><h2>'.$package.'</h2>';
    $out .= '<div class="txt">'.do_shortcode($content).'</div>';
    $out .= '<a class="btn" href="'.$btn_url.'">'.$btn_txt.'</a> </div></div></li>';
    return $out;
}
add_shortcode('price_col', 'pricing_col_shortcode');
// Projects Shortcode
function projects_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = "Project Title";
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = "Button Text";
    }
    if(!empty($atts['btn_url'])){
        $btn_url = $atts['btn_url'];
    } else {
        $btn_url = "#";
    }
    if(!empty($atts['img_url'])){
        $img_url = $atts['img_url'];
    } else {
        $img_url = "#";
    }
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['img_position'])){
        $img_position = $atts['img_position'];
    } else {
        $img_position = "right";
    }
    $out = '';
    $out .= '<ul class="row projects">';
    if($img_position == "right"){
        $out .= '<li class="col-sm-6 wow ltxt '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s"><div class="project-detail">';
        $out .= '<h4>'.$title.'</h4>';
        $out .= '<p>'.do_shortcode($content).'</p>';
        $out .= '<a class="btn" href="'.$btn_url.'">'.$btn_txt.'</a> </div></li>';
        $out .= '<li class="col-sm-6 wow rimg '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
        $out .= '<img  class="img-responsive" src="'.$img_url.'" alt="">';
        $out .= '</li>';
    } else {
        $out .= '<li class="col-sm-6 wow limg '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
        $out .= '<img  class="img-responsive" src="'.$img_url.'" alt="">';
        $out .= '</li>';
        $out .= '<li class="col-sm-6 wow rtxt '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s"><div class="project-detail">';
        $out .= '<h4>'.$title.'</h4>';
        $out .= '<p>'.do_shortcode($content).'</p>';
        $out .= '<a class="btn" href="'.$btn_url.'">'.$btn_txt.'</a> </div></li>';
    }
    $out .= '</ul>';
    return $out;
}
add_shortcode('projects', 'projects_shortcode');
// Counters Shortcode
function counters_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div id="counters"><div class="container">';
    $out .= '<ul class="row">';
    $out .= do_shortcode($content);
    $out .= '</ul></div></div>';
    return $out;
}
add_shortcode('counters', 'counters_shortcode');
add_shortcode('counter', 'counter_shortcode');
function counter_shortcode( $atts, $content = null){
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = 1;
    }
    if(!empty($atts['value'])){
        $value = $atts['value'];
    } else {
        $value = 1;
    }
    $out = '';
    $out .= '<li class="col-sm-3 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.2s">';
  	$out .= '<input type="hidden" id="count'.$number.'" value="'.$value.'">';
    $out .= '<span class="count'.$number.'">'.$value.'</span>';
    $out .= '<hr class="counter-line">';
    $out .= '<p>'.$content.'</p>';
    $out .= '</li>';
    return $out;
}
// Testimonials
function testimonials_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['number'])){
        $number = $atts['number'];
    } else {
        $number = -1;
    }
    wp_enqueue_script('jquery.flexslider-min', get_template_directory_uri() . '/js/jquery.flexslider-min.js', array('jquery'), '', true  );
     ?>
    <div class="flexslider">
        <ul class="slides testimonials">
            <?php
            $args = array(
                'post_type'      => 'mikos-testimonials',
                'posts_per_page' => $number
            );
            $testimonials_query = new WP_Query( $args );
            while($testimonials_query->have_posts()): $testimonials_query->the_post();
            ?>
            <li>
                <?php the_content(); ?>
            </li>
            <?php endwhile; ?>
        </ul>
    </div>
<?php
}
add_shortcode('testimonials', 'testimonials_shortcode');
// Services
function services_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div class="services"><ul class="row">';
    $out .= do_shortcode($content);
    $out .= '</ul></div>';
    return $out;
}
add_shortcode('services', 'services_shortcode');
add_shortcode('service', 'shortcode_service');
function shortcode_service( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['col'])){
        if($atts['col'] == 2){
            $col = 6;
        } elseif($atts['col'] == 4){
            $col = 3;
        } else {
            $col = 4;
        }
    } else {
        $col = 4;
    }
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = 'Your Title';
    }
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['icon'])){
        $icon = $atts['icon'];
    } else {
        $icon = 'user';
    }
    $out = '';
    $out .= '<li class="col-xs-12 col-md-'.$col.' wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
    $out .= '<div class="icon"><span aria-hidden="true" class="icon-'.$icon.'"></span> </div><div class="ser-sec">';
    $out .= '<h5>'.$title.'</h5><hr>';
    $out .= '<p>'.do_shortcode($content).'</p>';
    $out .= '</div></li>';
    return $out;
}
// Team
function team_shortcode( $atts, $content = null ) {
extract(shortcode_atts(array(
), $atts));
    if(!empty($atts['members'])){
        $members = $atts['members'];
    } else {
        $members = 3;
    } ?>
<div class="team">
            <ul class="row">
                <?php
                $posts = array(
                    'post_type' => 'mikos-team',
                    'posts_per_page' => $members
                );
$team_post = new WP_Query($posts);
while($team_post->have_posts()): $team_post->the_post();
    $designation = get_field("designation");
    $img = get_field("member_image");
    $facebook = get_field("facebook");
    $twitter = get_field("twitter");
    $google = get_field("google_plus");
    ?>
    <!--TEAM MEMBER-->
    <li class="col-md-4 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">
        <div class="avatar">
            <div class="img" style="background-image: url(<?php echo $img; ?>);">
              <div class="info">
                  <h5><?php the_title(); ?></h5>
              </div>
              <div class="line">
                  <hr>
              </div>
                <div class="designation">
                  <p><?php echo $designation; ?></p>
                </div>


                <div class="over">
                    <div class="social_icons">
                        <ul>
                            <?php if(!empty($facebook)){ ?>
                                <li class="facebook"> <a href="<?php echo $facebook; ?>"><i class="fa fa-facebook"></i> </a> </li>
                            <?php } if(!empty($twitter)){ ?>
                                <li class="twitter"> <a href="<?php echo $twitter; ?>"><i class="fa fa-twitter"></i> </a> </li>
                            <?php } if(!empty($google)){ ?>
                                <li class="googleplus"> <a href="<?php echo $google; ?>"><i class="fa fa-google"></i> </a> </li>
                            <?php } ?>
                        </ul>
                    </div>
                    <div class="helper">

                    </div>
                </div>
            </div>
        </div>

    </li>
<?php endwhile; ?>
</ul>
</div>
<?php
}
add_shortcode('team', 'team_shortcode');

// Image Shortcode
function image_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['col'])){
        if($atts['col'] == 2){
            $col = 6;
        } elseif($atts['col'] == 4){
            $col = 3;
        } else {
            $col = 4;
        }
    } else {
        $col = 4;
    }
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['url'])){
        $url = $atts['url'];
    } else {
        $url = '';
    }
    $out = '';
    $out .= '<div class="col-sm-'.$col.' wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
    $out .= '<img class="img-responsive" src="'.$url.'" alt="">';
    $out .= '</div>';
    return $out;
}
add_shortcode('image', 'image_shortcode');

// Row Shortcode
function row_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['row_class'])){
        $row_class = $atts['row_class'];
    } else {
        $row_class = "";
    }
    $out = '';
    $out .= '<div class="row '.$row_class.'">' . do_shortcode($content) .'</div>';
    return $out;
}
add_shortcode('row', 'row_shortcode');

// Space Shortcode
function space_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['space'])){
        $space = $atts['space'];
    } else {
        $space = 0;
    }
    $out = '';
    $out .= '<div style="margin-top: '.$space.'px; width: 100%;float:left;"></div>';
    return $out;
}
add_shortcode('space', 'space_shortcode');


// Column Shortcode
function column_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
	if( isset($atts['col_class'])):
		if($atts['col_class'] == "xs"){
			$class = "col-xs-";
		} elseif($atts['col_class'] == "sm") {
			$class = "col-sm-";
		} elseif($atts['col_class'] == "md") {
			$class = "col-md-";
		} elseif($atts['col_class'] == "lg") {
			$class = "col-lg-";
		} else {
			$class = "col-sm-";
		}
	else: $class = "col-sm-";
    endif;

    $out = '';
    $out .= '<div class="' . $class.$atts['size'] . '" >' . do_shortcode($content) .'</div>';
    return $out;
}
add_shortcode('column', 'column_shortcode');


// Title Shortcode
function title_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['animation_heading'])){
        $animation_heading = $atts['animation_heading'];
    } else {
        $animation_heading = 'fadeInUp';
    }
    if(!empty($atts['duration_heading'])){
        $duration_heading = $atts['duration_heading'];
    } else {
        $duration_heading = 1;
    }
    if(!empty($atts['heading'])){
        $heading = $atts['heading'];
    } else {
        $heading = "Your Heading";
    }
    if(!empty($atts['animation_btn'])){
        $animation_btn = $atts['animation_btn'];
    } else {
        $animation_btn = 'fadeInUp';
    }
    if(!empty($atts['duration_btn'])){
        $duration_btn = $atts['duration_btn'];
    } else {
        $duration_btn = 1;
    }
    if(!empty($atts['btn_link'])){
        $btn_link = $atts['btn_link'];
    } else {
        $btn_link = "#";
    }
    if(!empty($atts['btn_txt'])){
        $btn_txt = $atts['btn_txt'];
    } else {
        $btn_txt = "Button";
    }
    $out = '<div class="tittle">';
    $out .= '<h2 class="wow '.$animation_heading.'" data-wow-duration="'.$duration_heading.'s" data-wow-delay="0.5s">'.$heading.'</h2>';
    $out .= '<p>'.do_shortcode($content).'</p>';
    $out .= '<a  class="btn wow '.$animation_btn.'" data-wow-duration="'.$duration_btn.'s" data-wow-delay="1s" href="'.$btn_link.'">'.$btn_txt.'</a>';
    $out .= '</div></div>';
    return $out;
}
add_shortcode('title', 'title_shortcode');
// Social Shortcode
function social_shortcode( $atts) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['link_type'])){
        $link = $atts['link_type'];
    } else {
        $link = 'target="_blank"';
    }
    if($link == "yes"){
        $link = 'target="_blank"';
    }else {
        $link = '';
    }

    if(!empty($atts['facebook'])){
        $facebook = '<li class="facebook"><a href="'.$atts['facebook'].'" class="fa fa-facebook" '.$link.'></a></li>';
    } else{
        $facebook = '';
    }
    if(!empty($atts['dribble'])){
        $dribble = '<li class="dribbble"><a href="'.$atts['dribble'].'" class="fa fa-dribbble" '.$link.'></a></li>';
    } else{
        $dribble = '';
    }
    if(!empty($atts['twitter'])){
        $twitter = '<li class="twitter"><a href="'.$atts['twitter'].'" class="fa fa-twitter" '.$link.'></a></li>';
    } else{
        $twitter = '';
    }
    if(!empty($atts['linkedin'])){
        $linkedin = '<li class="linkedin"><a href="'.$atts['linkedin'].'" class="fa fa-linkedin" '.$link.'></a></li>';
    } else{
        $linkedin = '';
    }
    if(!empty($atts['pinterest'])){
        $pinterest = '<li class="pinterest"><a href="'.$atts['pinterest'].'" class="fa fa-pinterest" '.$link.'></a></li>';
    } else{
        $pinterest = '';
    }
    if(!empty($atts['google'])){
        $google = '<li class="googleplus"><a href="'.$atts['google'].'" class="fa fa-google" '.$link.'></a></li>';
    } else{
        $google = '';
    }

    $out = '';
    $out .= '<div class="connect"><div class="social_icons"><ul>';
    $out .= $facebook;
    $out .= $twitter;
    $out .= $linkedin;
    $out .= $pinterest;
    $out .= $google;
    $out .= $dribble;
    $out .= '</ul></div></div>';
    return $out;
}
add_shortcode('social', 'social_shortcode');

// Button Shortcode
function button_shortcode( $atts) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['button_text'])) {
        $text = $atts['button_text'];
    } else {
        $text = "Read More";
    }
    if(!empty($atts['button_style'])){
        $class = $atts['button_style'];
    } else {
        $class = '';
    }
    if(!empty($atts['button_link'])){
        $link = $atts['button_link'];
    } else {
        $link = "#";
    }
    $out = '';
    $out .= '<a href="'.$link.'" class="btn btn-outline read-more '. $class .'">'. $text .'</a>';
    return $out;
}
add_shortcode('button', 'button_shortcode');


// Flex Slider Shortcode
function flex_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div id="slider" class="slider fit">';
    $out .= '<ul class="slides">';
    $out .= do_shortcode($content);
    $out .= '</ul></div>';
    return $out;
}
add_shortcode('slides', 'flex_shortcode');
// Tabs Shortcode
add_shortcode('tabs', 'shortcode_tabs');
function shortcode_tabs( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));

    $out = '';
    $out .= '<ul class="nav nav-tabs" role="tablist">';
    $i = 1;
    foreach ($atts as $key => $tab) {
        if($i == 1) {
            $out .= '<li role="presentation" class="active"><a href="#' . $key . '" aria-controls="'. $key .'" role="tab" data-toggle="tab">' . $tab . '</a></li>';
        } else {
            $out .= '<li role="presentation"><a href="#' . $key . '" aria-controls="'. $key .'" role="tab" data-toggle="tab">' . $tab . '</a></li>';
        }
        $i++;
    }
    $out .= '</ul>';
    $out .= '<div class="tab-content">';
    $out .= do_shortcode($content);
    $out .= '</div>';
    return $out;
}
add_shortcode('tab', 'shortcode_tab');
function shortcode_tab( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<div role="tabpanel" class="tab-pane fade" id="tab' . $atts['id'] . '" >' . do_shortcode($content) .'</div>';
    return $out;
}
// List Style Shortcode
function lists_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<ul class="link-list">';
    $out .= do_shortcode($content);
    $out .= '</ul>';
    return $out;
}
add_shortcode('lists', 'lists_shortcode');
function list_shortcode( $atts, $content = null) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= '<li>';
    $out .= do_shortcode($content);
    $out .= '</li>';
    return $out;
}
add_shortcode('list', 'list_shortcode');
// Youtube Shortcode
function youtube_shortcode( $atts ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['url'])){
        $url = $atts['url'];
    } else {
        $url = '';
    }
    if(!empty($atts['width'])){
        $width = $atts['width'];
    } else {
        $width = "100%";
    }
    if(!empty($atts['height'])){
        $height = $atts['height'];
    } else {
        $height = "300";
    }
    $out = '';
    $out .= '<iframe width="'.$width.'" height="'. $height .'" src="'. $url .'"></iframe>';
    return $out;
}
add_shortcode('youtube', 'youtube_shortcode');


// Vimeo Shortcode
function vimeo_shortcode( $atts ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['id'])){
        $id = $atts['id'];
    } else {
        $id = '';
    }
    if(!empty($atts['width'])){
        $width = $atts['width'];
    } else {
        $width = "100%";
    }
    if(!empty($atts['height'])){
        $height = $atts['height'];
    } else {
        $height = "300";
    }
    $out = '';
    $out .= '<iframe src="http://player.vimeo.com/video/'.$id.'" width="'.$width.'" height="'.$height.'" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>';
    return $out;
}
add_shortcode('vimeo', 'vimeo_shortcode');
// Soundcloud Shortcode
function soundcloud_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    $out = '';
    $out .= do_shortcode($content);
    return $out;
}
add_shortcode('soundcloud', 'soundcloud_shortcode');

// About Shortcode
function about_shortcode( $atts, $content = null ) {
    extract(shortcode_atts(array(
    ), $atts));
    if(!empty($atts['title'])){
        $title = $atts['title'];
    } else {
        $title = "About Title";
    }
    if(!empty($atts['img_url'])){
        $img_url = $atts['img_url'];
    } else {
        $img_url = "#";
    }
    if(!empty($atts['animation'])){
        $animation = $atts['animation'];
    } else {
        $animation = 'fadeInUp';
    }
    if(!empty($atts['duration'])){
        $duration = $atts['duration'];
    } else {
        $duration = 1;
    }
    if(!empty($atts['img_position'])){
        $img_position = $atts['img_position'];
    } else {
        $img_position = "right";
    }
    $out = '';
    $out .= '<ul class="row about">';
    if($img_position == "right"){
        $out .= '<li class="col-sm-6 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
        $out .= '<div class="chield-about"><h3>'.$title.'</h3>.</div>';
        $out .= '<div class="about-hlp"></div>';
        $out .= '</li>';
        $out .= '<li class="col-sm-6 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s"  style="height=300px">';
        $out .= '<div class="back_about" style="background-image: url('.$img_url.');"></div>';
        $out .= '</li>';
    } else {
        $out .= '<li class="col-sm-6 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
        $out .= '<div class="back_about" style="background-image: url('.$img_url.');"></div>';
        $out .= '</li>';
        $out .= '<li class="col-sm-6 wow '.$animation.'" data-wow-duration="'.$duration.'s" data-wow-delay="0.3s">';
        $out .= '<div class="chield-about"><h3>'.$title.'</h3>.</div>';
        $out .= '<div class="about-hlp"></div>';
        $out .= '</li>';
    }
    $out .= '</ul>';
    return $out;
}
add_shortcode('about', 'about_shortcode');
