<?php
/*
 * Projects Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map(
    array(
        'name'                    => __( 'Projects', 'js_composer' ),
        'base'                    => 'mikos_projects',
        'category'                => __( 'Mikos', 'js_composer' ),
        'as_parent' 		      => array('only' => 'mikos_projects_item'),
        'content_element'         => true,
        'show_settings_on_create' => false,
        'js_view'                 => 'VcColumnView',
        'params'          		  => array(
            array(
                'type' 		  => 'textfield',
                'heading' 	  => __( 'Extra class name', 'js_composer' ),
                'param_name'  => 'el_class',
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
                'value' 	  => ''
            ),
            array(
                'type' 		  => 'css_editor',
                'heading' 	  => __( 'CSS box', 'js_composer' ),
                'param_name'  => 'css',
                'group' 	  => __( 'Design options', 'js_composer' )
            )
        ) //end params
    )
);

class WPBakeryShortCode_mikos_projects extends WPBakeryShortCodesContainer {
    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'css'	   => '',
            'el_class' => ''
        ), $atts ) );

        $class  = ( ! empty( $el_class ) ) ? $el_class : '';
        $class .= vc_shortcode_custom_css_class( $css, ' ' );

        $output = '';

        global $mikos_projects_items;
        $mikos_projects_items = '';

        do_shortcode( $content );

        if( ! empty( $mikos_projects_items ) && count( $mikos_projects_items ) > 0 ) {

            foreach ( $mikos_projects_items as $key => $item ) {
                $value = (object)$item['atts'];

                $image = (!empty($value->image) && is_numeric($value->image)) ? wp_get_attachment_url($value->image) : '';

                $title = (!empty($value->title)) ? '<h4>' . $value->title . '</h4>' : '';
                $text = (!empty($value->text)) ? '<p>' . wp_kses_post($value->text) . '</p>' : '';

                $link = (!empty($value->button)) ? vc_build_link($value->button) : '';
                $link_target = (!empty($link['target'])) ? 'target="' . $link['target'] . '"' : '';
                $button = (!empty($link)) ? '<a href="' . esc_url($link['url']) . '" class="btn" ' . $link_target . '>' . esc_html($link['title']) . '</a>' : '';

                // Image position
                $image_position = ( isset( $value->image_position ) && $value->image_position == 'right' ) ? 'right' : 'left';
              
                // Animation type
                $animation_type = ( isset( $value->animation_type ) ) ? $value->animation_type : 'fadeInUp';

                // Project content

                $output .= '<ul class="row projects ' . $class . '">';

                if( ! empty( $image ) || ! empty( $title ) || ! empty( $text ) || ! empty( $link['url'] ) || ! empty( $link['title'] ) ) {
                    if ($image_position == 'left') :
                        // Project image
                        $output .= '<li class="col-sm-6 wow rimg ' . $animation_type . '" data-wow-duration="0.3s" data-wow-delay="0.3s">';
                            $output .= '<img  class="img-responsive" src="' . esc_url( $image ) . '" alt="">';
                        $output .= '</li>';
                    endif;

                    $output .= '<li class="col-sm-6 wow ltxt ' . $animation_type . '" data-wow-duration="0.3s" data-wow-delay="0.3s"><div class="project-detail">';
                        $output .= $title;
                        $output .= $text;
                        $output .= $button;
                    $output .= '</div></li>';

                    if( $image_position == 'right' ) :
                        // Project image
                        $output .= '<li class="col-sm-6 wow rimg ' . $animation_type . '" data-wow-duration="0.3s" data-wow-delay="0.3s">';
                            $output .= '<img  class="img-responsive" src="' . esc_url( $image ) . '" alt="">';
                        $output .= '</li>';
                    endif;
                }

                $output .= '</ul>';

            }

        }
        return $output;
    }
}

vc_map(
    array(
        'name'            => 'Item',
        'base'            => 'mikos_projects_item',
        'as_child' 		  => array('only' => 'mikos_projects'),
        'content_element' => true,
        'params'          => array(
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Title', 'js_composer' ),
                'admin_label' => true,
                'param_name'  => 'title'
            ),
            array(
                'type'        => 'textarea',
                'heading'     => __( 'Text', 'js_composer' ),
                'param_name'  => 'text'
            ),
            array(
                'type' 		  => 'vc_link',
                'heading' 	  => __( 'Button', 'js_composer' ),
                'param_name'  => 'button'
            ),
            array(
                'type'        => 'attach_image',
                'heading'     => __( 'Photo', 'js_composer' ),
                'param_name'  => 'image'
            ),
            array(
                'heading' 	  => __( 'Image Position', 'js_composer' ),
                'type' 		  => 'dropdown',
                'param_name'  => 'image_position',
                'value' 	  => array(
                    __( 'Left', 'js_composer' )   => 'left',
                    __( 'Right', 'js_composer' )  => 'right',
                )
            ),
            array(
                'heading' 	  => __( 'Animation Type', 'js_composer' ),
                'type' 		  => 'dropdown',
                'param_name'  => 'animation_type',
                'value' 	  => array(
                    __( 'Bounce', 'js_composer' ) => 'bounce',
                    __( 'Flash', 'js_composer' )  => 'flash',
                    __( 'Fade In', 'js_composer' )  => 'fadeIn',
                    __( 'Fade In Down', 'js_composer' )  => 'fadeInDown',
                    __( 'Fade In Left', 'js_composer' )  => 'fadeInLeft',
                    __( 'Fade In Right', 'js_composer' )  => 'fadeInRight',
                    __( 'Fade In Up', 'js_composer' )  => 'fadeInUp',
                    __( 'Fade Out', 'js_composer' )  => 'fadeOut',
                    __( 'Flip In X', 'js_composer' )  => 'flipInX',
                    __( 'Flip In Y', 'js_composer' )  => 'flipInY',
                    __( 'Rotate In', 'js_composer' )  => 'rotateIn',
                )
            ),
        ),
    )
);


class WPBakeryShortCode_mikos_projects_item extends WPBakeryShortCode{
    protected function content( $atts, $content = null ) {
        global $mikos_projects_items;
        $mikos_projects_items[] = array( 'atts' => $atts, 'content' => $content);
        return;
    }
}