<?php
/*
 * Projects Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map(
    array(
        'name'                    => __( 'Testimonials', 'js_composer' ),
        'base'                    => 'mikos_testimonials',
        'category'                => __( 'Mikos', 'js_composer' ),
        'as_parent' 		      => array('only' => 'mikos_testimonials_item'),
        'content_element'         => true,
        'show_settings_on_create' => false,
        'js_view'                 => 'VcColumnView',
        'params'          		  => array(
            array(
                'type' 		  => 'textfield',
                'heading' 	  => __( 'Extra class name', 'js_composer' ),
                'param_name'  => 'el_class',
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
                'value' 	  => ''
            ),
            array(
                'type' 		  => 'css_editor',
                'heading' 	  => __( 'CSS box', 'js_composer' ),
                'param_name'  => 'css',
                'group' 	  => __( 'Design options', 'js_composer' )
            )
        ) //end params
    )
);

class WPBakeryShortCode_mikos_testimonials extends WPBakeryShortCodesContainer {
    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'css'	   => '',
            'el_class' => ''
        ), $atts ) );

        $class  = ( ! empty( $el_class ) ) ? $el_class : '';
        $class .= vc_shortcode_custom_css_class( $css, ' ' );

        $output = '';

        global $mikos_testimonials_items;
        $mikos_testimonials_items = '';

        do_shortcode( $content );

        wp_enqueue_script('jquery.flexslider-min', get_template_directory_uri() . '/js/jquery.flexslider-min.js', array('jquery'), '', true  );

        if( ! empty( $mikos_testimonials_items ) && count( $mikos_testimonials_items ) > 0 ) {

            $output .= '<div class="parallax">';
            $output .= '<div class="flexslider ' . $class . '">';
                $output .= '<ul class="slides testimonials">';
                    foreach ( $mikos_testimonials_items as $key => $item ) {
                        $value = (object)$item['atts'];

                        $title_color = ( ! empty( $value->title_color ) ) ? 'style="color: ' . $value->title_color . '"' : '';
                        $content_color = ( ! empty( $value->content_color ) ) ? 'style="color: ' . $value->content_color . '"' : '';

                        $title = ( ! empty( $value->title ) ) ? '<h5><strong ' . $title_color . '>' . $value->title . '</strong></h5>' : '';
                        $text = ( ! empty( $item['content'] ) ) ? '<p ' . $content_color . '>' . wp_kses_post( $item['content'] ) . '</p>' : '';

                        // Project content
                        if( ! empty( $text ) || ! empty( $title ) ) {
                            $output .= '<li>';
                                $output .= $text;
                                $output .= $title;
                            $output .= '</li>';
                        }

                    }
                $output .= '</ul>';
            $output .= '</div>';
            $output .= '</div>';

        }
        return $output;
    }
}

vc_map(
    array(
        'name'            => 'Item',
        'base'            => 'mikos_testimonials_item',
        'as_child' 		  => array('only' => 'mikos_testimonials'),
        'content_element' => true,
        'params'          => array(
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Author', 'js_composer' ),
                'admin_label' => true,
                'param_name'  => 'title'
            ),
            array(
                'type'        => 'textarea_html',
                'heading'     => __( 'Text', 'js_composer' ),
                'param_name'  => 'content',
                'holder'  	  => 'div',
                'value' 	  => ''
            ),
            array(
                'type'        => 'colorpicker',
                'heading'     => __( 'Title color', 'js_composer' ),
                'param_name'  => 'title_color',
                'group'       => __( 'Style', 'js_composer' )
            ),
            array(
                'type'        => 'colorpicker',
                'heading'     => __( 'Content color', 'js_composer' ),
                'param_name'  => 'content_color',
                'group'       => __( 'Style', 'js_composer' )
            ),
        ),
    )
);


class WPBakeryShortCode_mikos_testimonials_item extends WPBakeryShortCode{
    protected function content( $atts, $content = null ) {
        global $mikos_testimonials_items;
        $mikos_testimonials_items[] = array( 'atts' => $atts, 'content' => $content);
        return;
    }
}