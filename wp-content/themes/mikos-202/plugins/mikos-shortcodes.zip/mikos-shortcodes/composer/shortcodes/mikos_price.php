<?php
/*
 * Pricing Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map(
    array(
        'name'                    => __( 'Pricing', 'js_composer' ),
        'base'                    => 'mikos_price',
        'category'                => __( 'Mikos', 'js_composer' ),
        'as_parent' 		      => array('only' => 'mikos_price_item'),
        'content_element'         => true,
        'show_settings_on_create' => false,
        'js_view'                 => 'VcColumnView',
        'params'          		  => array(
            array(
                'type' 		  => 'textfield',
                'heading' 	  => __( 'Extra class name', 'js_composer' ),
                'param_name'  => 'el_class',
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
                'value' 	  => ''
            ),
            array(
                'type' 		  => 'css_editor',
                'heading' 	  => __( 'CSS box', 'js_composer' ),
                'param_name'  => 'css',
                'group' 	  => __( 'Design options', 'js_composer' )
            )
        ) //end params
    )
);

class WPBakeryShortCode_mikos_price extends WPBakeryShortCodesContainer {
    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'css'	   => '',
            'el_class' => ''
        ), $atts ) );

        $class  = ( ! empty( $el_class ) ) ? $el_class : '';
        $class .= vc_shortcode_custom_css_class( $css, ' ' );

        $output = '';

        global $mikos_price_items;
        $mikos_price_items = '';

        do_shortcode( $content );

        if( ! empty( $mikos_price_items ) && count( $mikos_price_items ) > 0 ) {

            $output .= '<ul class="row pricing ' . esc_attr( $class ) . '">';
            foreach ( $mikos_price_items as $key => $item ) {
                $value = (object)$item['atts'];

                $output .= '<li class="col-md-4 wow fadeInUp" data-wow-duration="0.3s" data-wow-delay="0.3s"><div>';

                // Pricing title
                if( ! empty( $value->title ) ) {
                    $output .= '<div class="head"><' . ( isset( $value->title_tag ) ? $value->title_tag : 'h2' ) . '>' . esc_html( $value->title ) . '</' . ( isset( $value->title_tag ) ? $value->title_tag : 'h2' ) . '> <hr class="price-line"></div>';
                }

                $output .= '<div class="pkg">';

                // Pricing price
                $currency = ( ! empty( $value->currency ) ) ? $value->currency : '';
                $output  .= ( ! empty( $value->price ) ) ? '<h2>' . $currency . esc_html( $value->price ) . '</h2>' : '';

                // Pricing content
                $text = ( ! empty( $item['content'] ) ) ? '<div class="txt">' . wp_kses_post( $item['content'] ) . '</div>' : '';
                $output .= $text;

                // Pricing button
                $link = ( ! empty( $value->button ) ) ? vc_build_link( $value->button ) : '';
                $link_target = ( ! empty( $link['target'] ) ) ? 'target="' . $link['target'] . '"' : '';
                $button = ( ! empty( $link ) ) ? '<div class="price-button"><a href="' . esc_url( $link['url'] ) . '" class="btn" ' . $link_target . '>' . esc_html( $link['title'] ) . '</a></div>' : '';

                $output .= $button;
                $output .= '</div>';

                $output .= '</div></li>';
            }
            $output .= '</ul>';

        }
        return $output;
    }
}

vc_map(
    array(
        'name'            => 'Item',
        'base'            => 'mikos_price_item',
        'as_child' 		  => array('only' => 'mikos_price'),
        'content_element' => true,
        'params'          => array(
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Title', 'js_composer' ),
                'admin_label' => true,
                'param_name'  => 'title'
            ),
            array(
                'heading' 	  => __( 'Title tag', 'js_composer' ),
                'type' 		  => 'dropdown',
                'param_name'  => 'title_tag',
                'value' 	  => array(
                    __( 'H2', 'js_composer' ) => 'h2',
                    __( 'H3', 'js_composer' ) => 'h3',
                    __( 'H4', 'js_composer' ) => 'h4',
                    __( 'H5', 'js_composer' ) => 'h5',
                    __( 'H6', 'js_composer' ) => 'h6',
                )
            ),
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Currency', 'js_composer' ),
                'param_name'  => 'currency',
                'value'       => '',
                'description' => __( 'Use currency icons, like $, €...', 'js_composer' )
            ),
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Price', 'js_composer' ),
                'param_name'  => 'price',
                'value'		  => ''
            ),
            array(
                'type'        => 'textarea_html',
                'heading'     => __( 'Text', 'js_composer' ),
                'param_name'  => 'content',
                'holder'  	  => 'div',
                'value' 	  => ''
            ),
            array(
                'type' 		 => 'vc_link',
                'heading' 	 => __( 'Button', 'js_composer' ),
                'param_name' => 'button'
            ),
        ),
    )
);


class WPBakeryShortCode_mikos_price_item extends WPBakeryShortCode{
    protected function content( $atts, $content = null ) {
        global $mikos_price_items;
        $mikos_price_items[] = array( 'atts' => $atts, 'content' => $content);
        return;
    }
}
