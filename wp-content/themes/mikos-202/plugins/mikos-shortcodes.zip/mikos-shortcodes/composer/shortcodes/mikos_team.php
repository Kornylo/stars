<?php
/*
 * Team Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map(
    array(
        'name'                    => __( 'Team', 'js_composer' ),
        'base'                    => 'mikos_team',
        'category'                => __( 'Mikos', 'js_composer' ),
        'as_parent' 		      => array('only' => 'mikos_team_item'),
        'content_element'         => true,
        'show_settings_on_create' => false,
        'js_view'                 => 'VcColumnView',
        'params'          		  => array(
            array(
                'type' 		  => 'textfield',
                'heading' 	  => __( 'Extra class name', 'js_composer' ),
                'param_name'  => 'el_class',
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
                'value' 	  => ''
            ),
            array(
                'type' 		  => 'css_editor',
                'heading' 	  => __( 'CSS box', 'js_composer' ),
                'param_name'  => 'css',
                'group' 	  => __( 'Design options', 'js_composer' )
            )
        ) //end params
    )
);

class WPBakeryShortCode_mikos_team extends WPBakeryShortCodesContainer {
    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'css'	   => '',
            'el_class' => ''
        ), $atts ) );

        $google_fonts = new Vc_Google_Fonts;

        $class  = ( ! empty( $el_class ) ) ? $el_class : '';
        $class .= vc_shortcode_custom_css_class( $css, ' ' );

        $output = '';

        global $mikos_team_items;
        $mikos_team_items = '';

        do_shortcode( $content );

        if( ! empty( $mikos_team_items ) && count( $mikos_team_items ) > 0 ) {

            $output .= '<div class="team ' . $class . '">';
                $output .= '<ul class="row">';
                    foreach ( $mikos_team_items as $key => $item ) {
                        $value = (object)$item['atts'];

                        $social = json_decode( urldecode( $value->social ) );
                        $image 	= ( ! empty( $value->image ) && is_numeric( $value->image ) ) ? wp_get_attachment_url( $value->image ) : '';

                        $name = (!empty($value->name)) ? '<div class="info"><h5>' . $value->name . '</h5></div>' : '';
                        $position = (!empty($value->position)) ? '<div class="designation"><p>' . $value->position . '</p></div>' : '';

                        $social_items = '';
                        if (!empty($social)) {
                            $social_items .= '<div class="social_icons">';
                            $social_items .= '<ul>';
                            foreach ($social as $social_item) {
                                $social_items .= '<li><a href="' . ( ! empty( $social_item->url ) ? esc_url($social_item->url) : '' ) . '"><i class="' . ( ! empty( $social_item->icon ) ? esc_attr($social_item->icon) : '' ) . '"></i></a></li>';
                            }
                            $social_items .= '</ul>';
                            $social_items .= '</div>';
                        }

                        if( ! empty( $image ) || ! empty( $name ) || ! empty( $position ) || $social_items ) {
                            $output .= '<li class="col-md-4 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.3s">';
                                $output .= '<div class="avatar">';

                                    // Team image
                                    $output .= '<div class="img" style="background-image: url(' . esc_url($image) . ');">';

                                    // Team name
                                    $output .= $name;
                                    $output .= '<div class="line">';
                                    $output .= '<hr>';
                                    $output .= '</div>';

                                    // Team position
                                    $output .= $position;

                                    $output .= '<div class="over">';

                                    // Team social
                                    $output .= $social_items;

                                    $output .= '<div class="helper"></div>';
                                    $output .= '</div>';
                                    $output .= '</div>';
                                $output .= '</div>';

                            $output .= '</li>';
                        }
                        
                    }
                $output .= '</ul>';
            $output .= '</div>';

        }
        return $output;
    }
}

vc_map(
    array(
        'name'            => 'Item',
        'base'            => 'mikos_team_item',
        'as_child' 		  => array('only' => 'mikos_team'),
        'content_element' => true,
        'params'          => array(
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Name', 'js_composer' ),
                'admin_label' => true,
                'param_name'  => 'name'
            ),
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Position', 'js_composer' ),
                'admin_label' => true,
                'param_name'  => 'position'
            ),
            array(
                'type'        => 'attach_image',
                'heading'     => __( 'Photo', 'js_composer' ),
                'param_name'  => 'image'
            ),
            /* Social */
            array(
                'type'       => 'param_group',
                'group'		 => 'Social',
                'heading'    => __( 'Social', 'js_composer' ),
                'param_name' => 'social',
                'params'     => array(
                    array(
                        'type'        => 'iconpicker',
                        'heading'     => __( 'Social icon', 'js_composer' ),
                        'param_name'  => 'icon',
                        'description' => __( 'Select icon from library.', 'js_composer' )
                    ),
                    array(
                        'type'        => 'textfield',
                        'heading'     => __( 'Socail URL', 'js_composer' ),
                        'param_name'  => 'url',
                        'value'       => ''
                    )
                ),
                'callbacks' => array(
                    'after_add' => 'vcChartParamAfterAddCallback'
                )
            ),
        ),
    )
);


class WPBakeryShortCode_mikos_team_item extends WPBakeryShortCode{
    protected function content( $atts, $content = null ) {
        global $mikos_team_items;
        $mikos_team_items[] = array( 'atts' => $atts, 'content' => $content);
        return;
    }
}