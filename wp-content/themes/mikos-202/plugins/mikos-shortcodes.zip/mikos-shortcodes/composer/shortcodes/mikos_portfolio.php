<?php
/*
 * Portfolio Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map( array(
    'name'            => __( 'Portfolio', 'js_composer' ),
    'base'            => 'mikos_portfolio',
    'category'        => __( 'Mikos', 'js_composer' ),
    'description'     => __( 'Portfolio list', 'js_composer' ),
    'params'          => array(
        array(
            'type'        => 'vc_efa_chosen',
            'heading'     => __( 'Custom Categories', 'js_composer' ),
            'param_name'  => 'categories',
            'placeholder' => 'Choose category (optional)',
            'value'       => mikos_param_values( 'terms' ),
            'std'         => '',
            'admin_label' => true,
            'description' => __( 'You can choose spesific categories for blog, default is all categories', 'js_composer' ),
        ),
        array(
            'type' 		  => 'dropdown',
            'heading' 	  => 'Order by',
            'param_name'  => 'orderby',
            'admin_label' => true,
            'value' 	  => array(
                'ID' 		    => 'ID',
                'Author' 	    => 'author',
                'Post Title'    => 'title',
                'Date' 		    => 'date',
                'Last Modified' => 'modified',
                'Random Order'  => 'rand',
                'Menu Order'    => 'menu_order'
            )
        ),
        array(
            'type' 		  => 'dropdown',
            'heading' 	  => 'Order type',
            'param_name'  => 'order',
            'value' 	  => array(
                'Ascending'  => 'ASC',
                'Descending' => 'DESC'
            )
        ),
        array(
            'type'        => 'textfield',
            'heading'     => __( 'Count items', 'js_composer' ),
            'param_name'  => 'limit',
            'value'       => '',
            'admin_label' => true,
            'description' => __( 'Default 10 items.', 'js_composer' )
        ),

        /* Filter settings */
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Filter', 'js_composer' ),
            'param_name'  => 'filter_style',
            'value'       => array(
                'Hidden'  	=> 'hidden',
                'Show'  	=> 'show'
            ),
            'group' 	  => 'Filter settings'
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => __( 'Align', 'js_composer' ),
            'param_name'  => 'filter_align',
            'value'       => array(
                'Left'  	=> 'left',
                'Center'  	=> 'center',
                'Right'  	=> 'right'
            ),
            'dependency'  => array( 'element' => 'filter_style', 'value' => 'show' ),
            'group' 	  => 'Filter settings'
        ),
    )
));




class WPBakeryShortCode_mikos_portfolio extends WPBakeryShortCode{

    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'categories' 			  => '',
            'orderby' 				  => 'ID',
            'order' 				  => 'ASC',
            'limit' 				  => '',
            'filter_style' 			  => 'hidden',
            'filter_align' 			  => 'left'
        ), $atts ) );


        /* FOR PORTFOLIO  FILTERS */
        $limit = ( ! empty( $limit ) && is_numeric( $limit ) ) ? $limit : 10;

        // add filter align
        $filter_styles = ' text-' . $filter_align;

        /* FOR PORTFOLIO  CONTENT */

        // get $categories
        if ( empty($categories) ){
            // get all category potfolio
            $categories = array();
            $terms = get_terms('mikos_genre', 'orderby=name&hide_empty=0');
            foreach($terms as $term){
                $categories[] = $term->slug;
            }
        } else {
            $categories = explode( ',', $categories );
        }

        $post_item_attr = '';

        // params output
        $args = array(
            'posts_per_page' => $limit,
            'post_type'   	 => 'portfolio',
            'orderby'   	 => $orderby,
            'order'   		 => $order,
            'tax_query' 	 => array(
                array(
                    'taxonomy'  => 'mikos_genre',
                    'field'     => 'slug',
                    'terms'     => $categories
                )
            )
        );

        // get portfolio posts
        $portfolio = new WP_Query( $args );

        // start output
        ob_start(); ?>

        <div class="portfolio-wrapper">

            <?php if( $filter_style != 'hidden' ) { ?>
                <ul class="filter wow bounceIn <?php echo esc_attr( $filter_styles ); ?>" data-wow-delay="500ms">
                    <li><a class="active" href="#" data-filter="*"><?php esc_html_e('ALL', 'mikos'); ?></a></li>
                    <?php foreach ( $categories as $category_slug ) {
                        $category = get_term_by('slug', $category_slug, 'mikos_genre'); ?>
                        <li><a href="#" data-filter=".<?php echo esc_attr( $category->slug ); ?>"><?php echo esc_html($category->name); ?> </a></li>
                    <?php } ?>
                </ul>
            <?php } ?>

            <ul class="portfolio" id="popups">
                <ul class="items">

                    <?php while ( $portfolio->have_posts() ) : $portfolio->the_post();
                        setup_postdata( $portfolio );

                        $terms = get_the_terms( $portfolio->ID , 'mikos_genre' );
                        // add attribute item
                        $post_slug_category = array();
                        $post_item_attr = '';
                        foreach ($terms as $term) {
                            $post_slug_category[] = $term->name;
                            $post_item_attr .= $term->slug . ' ';
                        }

                        // Size items
                        $size = get_field("portfolio_item_size");
                        $size_column = ( $size == 'big' ) ? 'big' : '';

                        // Animation items
                        $disable_animation = get_field("disable_animation");
                        $animation_type = get_field("select_animation_type");
                        $animation_duration = get_field("animation_duration");
                        $animation_delay = get_field("animation_delay");

                        ?>

                        <li class="item mitem <?php echo esc_attr( $post_item_attr . ' ' . $size_column ); ?>">
                            <div class="img wow <?php if( $disable_animation != 1 ){ echo esc_attr( $animation_type ); } ?>" data-wow-duration="<?php echo intval( $animation_duration ); ?>s" data-wow-delay="<?php echo intval( $animation_delay ); ?>s">

                                <?php
                                if ( has_post_thumbnail() ) {
                                    the_post_thumbnail();
                                } else {
                                    echo "<img src=\"" . get_template_directory_uri() . "/images/no_photo.png\" alt=\"\" />";
                                }
                                ?>

                                <div class="over">
                                    <a href="<?php the_permalink(); ?>"></a>
                                    <div class="detail"><hr>
                                        <h5><?php the_title(); ?> </h5>
                                        <p><?php echo esc_html( strtoupper( implode( ', ', $post_slug_category ) ) ); ?></p><hr>
                                    </div>
                                    <div class="rasporka"></div>
                                </div>
                            </div>
                        </li>

                    <?php  endwhile; wp_reset_postdata(); ?>
                </ul>
            </ul>
        </div>

        <?php return ob_get_clean();

    } // end function content


}
