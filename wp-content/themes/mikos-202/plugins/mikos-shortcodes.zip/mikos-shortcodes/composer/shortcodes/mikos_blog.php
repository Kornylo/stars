<?php
/*
 * Blog Shortcode
 * Author: UPQODE
 * Author URI: http://upqode.com/
 * Version: 1.0.0
 */

vc_map(
    array(
        'name'            => __( 'Blog', 'js_composer' ),
        'base'            => 'mikos_blog',
        'category'        => __( 'Mikos', 'js_composer' ),
        'description'     => __( 'Posts list', 'js_composer' ),
        'params'          => array(
            array(
                'type'        => 'vc_efa_chosen',
                'heading'     => __( 'Custom Categories', 'js_composer' ),
                'param_name'  => 'categories',
                'placeholder' => 'Choose category (optional)',
                'value'       => mikos_param_values( 'categories' ),
                'std'         => '',
                'admin_label' => true,
                'description' => __( 'You can choose spesific categories for blog, default is all categories', 'js_composer' ),
            ),
            array(
                'type' 		  => 'dropdown',
                'heading' 	  => 'Order by',
                'param_name'  => 'orderby',
                'admin_label' => true,
                'value' 	  => array(
                    'ID' 		    => 'ID',
                    'Author' 	    => 'author',
                    'Post Title'    => 'title',
                    'Date' 		    => 'date',
                    'Last Modified' => 'modified',
                    'Random Order'  => 'rand',
                    'Menu Order'    => 'menu_order'
                )
            ),
            array(
                'type' 		  => 'dropdown',
                'heading' 	  => 'Order type',
                'param_name'  => 'order',
                'value' 	  => array(
                    'Ascending'  => 'ASC',
                    'Descending' => 'DESC'
                )
            ),
            array(
                'type'        => 'textfield',
                'heading'     => __( 'Count items', 'js_composer' ),
                'param_name'  => 'limit',
                'value'       => '',
                'admin_label' => true,
                'description' => __( 'Default 10 items.', 'js_composer' )
            ),
            array(
                'type' 		  => 'dropdown',
                'heading' 	  => 'Disable Animation',
                'param_name'  => 'disable_animation',
                'value' 	  => array(
                    'On'  => 'on',
                    'Off' => 'off'
                )
            ),
            array(
                'heading' 	  => __( 'Animation Type', 'js_composer' ),
                'type' 		  => 'dropdown',
                'param_name'  => 'animation_type',
                'value' 	  => array(
                    __( 'Bounce', 'js_composer' ) => 'bounce',
                    __( 'Flash', 'js_composer' )  => 'flash',
                    __( 'Fade In', 'js_composer' )  => 'fadeIn',
                    __( 'Fade In Down', 'js_composer' )  => 'fadeInDown',
                    __( 'Fade In Left', 'js_composer' )  => 'fadeInLeft',
                    __( 'Fade In Right', 'js_composer' )  => 'fadeInRight',
                    __( 'Fade In Up', 'js_composer' )  => 'fadeInUp',
                    __( 'Flip In X', 'js_composer' )  => 'flipInX',
                    __( 'Flip In Y', 'js_composer' )  => 'flipInY',
                    __( 'Rotate In', 'js_composer' )  => 'rotateIn',
                ),
                'dependency'  => array( 'element' => 'disable_animation', 'value' => 'on' )
            ),
            array(
                'type' 		  => 'textfield',
                'heading' 	  => __( 'Extra class name', 'js_composer' ),
                'param_name'  => 'el_class',
                'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'js_composer' ),
                'value' 	  => ''
            ),
            array(
                'type' 		  => 'css_editor',
                'heading' 	  => __( 'CSS box', 'js_composer' ),
                'param_name'  => 'css',
                'group' 	  => __( 'Design options', 'js_composer' )
            )
        )
    )
);

class WPBakeryShortCode_mikos_blog extends WPBakeryShortCode{

    protected function content( $atts, $content = null ) {

        extract( shortcode_atts( array(
            'categories'        => '',
            'orderby' 	        => 'ID',
            'order' 	        => 'ASC',
            'limit' 	        => '',
            'disable_animation' => 'on',
            'animation_type'    => 'fadeIn',
            'el_class' 	        => '',
            'css' 		        => ''
        ), $atts ) );

        /* Custom styles */

        $class  	= ( ! empty( $el_class ) ) ? $el_class : '';
        $class 	   .= vc_shortcode_custom_css_class( $css, ' ' );

        /* FOR BLOG CONTENT */

        // get $categories
        if ( empty( $categories ) ){
            // get all category blog
            $categories = array();
            $terms = get_categories();
            foreach($terms as $term){
                $categories[] = $term->slug;
            }
        } else {
            $categories = explode( ',', $categories );
        }

        // params output
        $args = array(
            'posts_per_page' => $limit,
            'post_type'   	 => 'post',
            'orderby'   	 => $orderby,
            'order'   		 => $order,
            'tax_query' 	 => array(
                array(
                    'taxonomy'  => 'category',
                    'field'     => 'slug',
                    'terms'     => $categories
                )
            )
        );

        // get blog posts
        $post = new WP_Query( $args );

        // start output
        ob_start(); ?>
        <div id="blog">
            <div class="blog">
                <div class="row">
                    <?php while ( $post->have_posts() ) : $post->the_post();

                        $terms = get_the_terms( $post->ID , 'category' );

                        // add attribute item
                        $post_slug_category = '';
                        $post_item_attr 	= '';
                        foreach ($terms as $term) {
                            $post_slug_category .= ' ' . $term->slug;
                            $post_item_attr 	.= ' ' . $term->slug;
                        } ?>

                        <?php $animation_type = ( isset( $animation_type ) && $animation_type == 'fadeIn' ) ? 'fadeIn' : $animation_type; ?>

                        <div class="col-md-4 wow <?php if( isset( $disable_animation ) && $disable_animation == 'on' ){ echo esc_attr( $animation_type ); } ?>" data-wow-duration="1s" data-wow-delay="0s">
                            <?php echo get_the_post_thumbnail( get_the_ID(), array( 360, 240) ); ?>
                            <div class="b-detail"><h6><?php echo get_the_time('M jS, Y'); ?></h6>
                                <a href="<?php the_permalink(); ?>"><?php the_title('<h5>', '</h5>'); ?></a>
                                <div class="b_links">
                                    <a href="<?php the_permalink(); ?>">&mdash; <?php esc_attr_e( 'READ MORE', 'mikos' ) ?></a>
                                </div>
                            </div>
                            <a href="<?php the_permalink(); ?>"></a>
                        </div>

                    <?php  endwhile; wp_reset_postdata(); ?>
                </div>
            </div>
        </div>

        <?php return ob_get_clean();

    } // end function content


}
