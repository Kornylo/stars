<?php
/*
Plugin Name: Mikos CPT
Plugin URI: http://lolli.pro
Description: Mikos custom post type's for only mikos wp theme.
Version: 1.0.2
Author: Lolli
Author URI: http://themeforest.net/user/lolli
License: GPLv2
*/
// Creating Page Sections CPT
function mikos_page_sections() {
    register_post_type( 'page-sections',
        array(
            'labels' => array(
                'name' => 'Page Sections',
                'singular_name' => 'Page Sections',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Page Section',
                'edit' => 'Edit',
                'edit_item' => 'Edit Page Section',
                'new_item' => 'New Page Section',
                'view' => 'View',
                'view_item' => 'View Page Section',
                'search_items' => 'Search Page Section',
                'not_found' => 'No Page Section found',
                'not_found_in_trash' => 'No Page Section found in Trash',
                'parent' => 'Parent Page Section'
            ),

            'public' => true,
            'menu_position' => 21,
            'supports' => array( 'title'),
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/sections.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'mikos_page_sections' );
// Creating mikos Portfolio CPT
function mikos_portfolio() {
    register_post_type( 'portfolio',
        array(
            'labels' => array(
                'name' => 'Portfolio',
                'singular_name' => 'Portfolio',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Portfolio',
                'edit' => 'Edit',
                'edit_item' => 'Edit Portfolio',
                'new_item' => 'New Portfolio',
                'view' => 'View',
                'view_item' => 'View Portfolio',
                'search_items' => 'Search Portfolio',
                'not_found' => 'No Portfolio found',
                'not_found_in_trash' => 'No Portfolio found in Trash',
                'parent' => 'Parent Portfolio'
            ),

            'public' => true,
            'menu_position' => 21,
            'show_in_nav_menus' => false,
            'supports' => array( 'title','editor','thumbnail'),
            'menu_icon' => plugins_url( 'img/portfolio.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'mikos_portfolio' );
add_action( 'init', 'mikos_taxonomies', 0 );
function mikos_taxonomies() {
    register_taxonomy(
        'mikos_genre',
        'portfolio',
        array(
            'labels' => array(
                'name' => 'Portfolio Items',
                'add_new_item' => 'Add New Portfolio Category',
                'new_item_name' => "New Portfolio Category"
            ),
            'show_ui' => true,
            'show_tagcloud' => false,
            'show_in_nav_menus' => false,
            'hierarchical' => true
        )
    );
}
// Creating Team CPT
function mikos_team() {
    register_post_type( 'mikos-team',
        array(
            'labels' => array(
                'name' => 'Team',
                'singular_name' => 'Team',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Member',
                'edit' => 'Edit',
                'edit_item' => 'Edit Member',
                'new_item' => 'New Member',
                'view' => 'View',
                'view_item' => 'View Member',
                'search_items' => 'Search Member',
                'not_found' => 'No Member found',
                'not_found_in_trash' => 'No Member found in Trash',
                'parent' => 'Parent Member'
            ),

            'public' => true,
            'supports' => array( 'title'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/team.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'mikos_team' );
// Creating Testimonial CPT
function mikos_testimonials() {
    register_post_type( 'mikos-testimonials',
        array(
            'labels' => array(
                'name' => 'Testimonials',
                'singular_name' => 'Testimonial',
                'add_new' => 'Add New',
                'add_new_item' => 'Add New Testimonial',
                'edit' => 'Edit',
                'edit_item' => 'Edit Testimonial',
                'new_item' => 'New Testimonial',
                'view' => 'View',
                'view_item' => 'View Testimonial',
                'search_items' => 'Search Testimonial',
                'not_found' => 'No Testimonial found',
                'not_found_in_trash' => 'No Testimonial found in Trash',
                'parent' => 'Parent Testimonial'
            ),

            'public' => true,
            'supports' => array( 'title','editor','thumbnail'),
            'show_in_nav_menus' => false,
            'taxonomies' => array( '' ),
            'menu_icon' => plugins_url( 'img/testimonials.png', __FILE__ ),
            'has_archive' => true
        )
    );
}
add_action( 'init', 'mikos_testimonials' );

// Text Widget Shortcode Readable
add_filter( 'widget_text', 'shortcode_unautop');
add_filter( 'widget_text', 'do_shortcode');
