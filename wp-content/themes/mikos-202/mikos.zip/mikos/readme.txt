Mikos-WP is a responsive portfolio Multipurpose Wordpress Theme for the professional creative. It�s easy to use and is made of HTML5 and CSS3.
